 // JavaScript to dynamically position particles all over the page
 document.addEventListener('DOMContentLoaded', function() {
    const symbols = ['+', '-', 'X', 'Q', '%', '=', 'T', 'M','Z','C'];
    const colors = ['#ffcc00', '#66ff99', '#ff6699', '#9966ff', '#66ccff', '#ff6666'];

    for (let i = 0; i < 70; i++) { // Adjust number of particles (100 in this case)
        const particle = document.createElement('div');
        const symbol = symbols[Math.floor(Math.random() * symbols.length)];
        const color = colors[Math.floor(Math.random() * colors.length)];
        particle.textContent = symbol;
        particle.classList.add('particle');
        particle.style.color = color;
        particle.style.left = `${Math.random() * window.innerWidth}px`;
        particle.style.top = `${Math.random() * window.innerHeight}px`;
        document.body.appendChild(particle);
    }
});


document.addEventListener('DOMContentLoaded', (event) => {
    var video = document.getElementById('background-video');
    video.playbackRate = 0.5; // Set playback speed to 0.5x (slower)
});